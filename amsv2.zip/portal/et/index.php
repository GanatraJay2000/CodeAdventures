<?php
header('Location: ./et/transaction.php');